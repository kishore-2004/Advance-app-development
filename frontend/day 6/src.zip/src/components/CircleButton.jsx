import React from 'react';
import { Link } from 'react-router-dom'; 
import '../assets/css/LoginButtons.css'; 

const LoginButtons = () => {
    return (
        <div className="login-buttons">
            <Link to="/admin-login" className="admin-login-button">
                Admin Login
            </Link>
            <Link to="/user-login" className="user-login-button">
                User Login
            </Link>
        </div>
    );
};

export default LoginButtons;
