
import './App.css'
// import AdminLogin from './components/AdminPage/loginpage';
import LoginButtons from './components/CircleButton';
function App() {


  return (
    <div>
      {/* <AdminLogin/> */}
      <LoginButtons/>
    </div>
    
  )
}

export default App
