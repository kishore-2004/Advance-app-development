import { useState } from 'react';
import '../../assets/css/eventdeatil.css';
// import AdminNav from './AdminNav';
import img1 from '../../assets/img/wed.jpg'
import img2 from '../../assets/img/HBD.jpg'
import img3 from '../../assets/img/anni.jpg'
import Nav from './navbar';

const ViewEvent = () => {
  const [events] = useState([
    { id: 1, image: img1, name: 'Wedding', description: 'A formal and elegant gown that the bride wears during the ceremony. The dress is often chosen to match the wedding theme and colors.' },
    { id: 2, image: img2, name: 'Birthday Party', description: 'A day filled with fun, laughter, and cake, surrounded by loved ones.A time to celebrate the special person in our lives, with all the things they love' },
    { id: 3, image: img3, name: 'Anniversary', description: 'Celebrating [number] years of love and laughter.Join us for a night of fun and memories as we celebrate our anniversary.' },
  ]);

  return (
    <div>
        <Nav/>
      {/* <AdminNav /> */}
      <div className="event-details">
        </div>
        <div className="event-cards-container">
          {events.map(event => (
            <div className="event-card" key={event.id}>
              <img src={event.image} alt={event.name} className="event-image" />
              <div className="event-info">
                <h3>{event.name}</h3>
                <p>{event.description}</p>
              </div>
            </div>
          ))}
        </div>
      </div>
  
  );
};

export default ViewEvent;
