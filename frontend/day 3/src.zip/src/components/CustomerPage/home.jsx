import '../../assets/css/home.css'
import Footer from '../Footer/Footer';
import Nav from "./navbar";

 
const Home = () => {
  return (
   
    <div className="home">  
    <Nav/>
    <div className='flex'>
    <div id='h-custom'>
      <h1 id='h1-cus'>Customizable wedding party booking software that increases revenue</h1>
      <div className='para-h'>
      <p id='h-sub'>Whether you are a solo party entertainer, manage a party venue, or have a mobile party truck, Bookeo handles your party bookings and helps your business grow. While you keep the party guests entertained and make sure that they have a good time.</p>
    </div>
    <a href='/bookingform'>
    <button id='bookbut'>Book The Venue</button></a>
    </div>
    <div  className='text-red-500'>
      <img src='https://cdn.dribbble.com/users/1021976/screenshots/2423268/1st-shot.gif' alt='img' />
    </div>
      </div>
    <Footer/></div>
  );
};
export default Home;
