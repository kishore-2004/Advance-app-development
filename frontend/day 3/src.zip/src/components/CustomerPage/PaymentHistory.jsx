// PaymentHistory.jsx
// import React from 'react';
import '../../assets/css/payment-history.css';
import Nav from './navbar';

const PaymentHistory = () => {
  // Sample payment history data
  const payments = [
    { id: 1, amount: 100, date: '2024-02-15', status: 'Paid' },
    { id: 2, amount: 150, date: '2024-02-18', status: 'Pending' },
    { id: 3, amount: 200, date: '2024-02-20', status: 'Failed' }
    // Add more payment data as needed
  ];

  return (
    <div>
      <Nav/>
      <div className="payment-history">
        <h2>Payment History</h2>
        <table>
          <thead>
            <tr>
              <th>Payment ID</th>
              <th>Amount</th>
              <th>Date</th>
              <th>Status</th>
            </tr>
          </thead>
          <tbody>
            {payments.map(payment => (
              <tr key={payment.id}>
                <td>{payment.id}</td>
                <td>${payment.amount}</td>
                <td>{payment.date}</td>
                <td className={`status-${payment.status.toLowerCase()}`}>{payment.status}</td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
    </div>
  );
};

export default PaymentHistory;
