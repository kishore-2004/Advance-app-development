import React, { Suspense } from 'react';

const LazyBookingForm = React.lazy(() => import('./Bookingpage'));

const ParentComponent = () => {
    return (
        <div>
            <Suspense fallback={<div>Loading...</div>}>
                <LazyBookingForm />
            </Suspense>
        </div>
    );
};

export default ParentComponent;
