
const AllBookings = () => {
  const bookings = [
    { id: 1, eventName: 'Birthday Party', date: '2024-05-10', customer: 'John Doe' },
    { id: 2, eventName: 'Wedding Ceremony', date: '2024-07-20', customer: 'Jane Smith' },
    { id: 3, eventName: 'Corporate Event', date: '2024-09-15', customer: 'David Brown' }
    // Add more bookings as needed
  ];

  return (
    <div className="allbookings">
      <h2>All Bookings</h2>
      <ul>
        {bookings.map(booking => (
          <li key={booking.id}>{booking.eventName} - {booking.date} - {booking.customer}</li>
        ))}
      </ul>
    </div>
  );
};

export default AllBookings;
