// import React from 'react';
import '../../assets/css/feedbackview.css'; // Import your CSS file
import AdminNav from './AdminNav';

const FeedbackView = () => {
  // Sample feedback data
  const feedbackData = [
    { id: 1, name: 'John Doe', email: 'john@example.com', feedback: 'Great service, will definitely recommend!' },
    { id: 2, name: 'Jane Smith', email: 'jane@example.com', feedback: 'The product exceeded my expectations.' },
    // Add more feedback data as needed
  ];

  return (
    <div>
        <AdminNav/>
    <div className="feedback-view-container">
      <h2>Feedback</h2>
      <table className="feedback-table">
        <thead>
          <tr>
            <th>Name</th>
            <th>Email</th>
            <th>Feedback</th>
          </tr>
        </thead>
        <tbody>
          {feedbackData.map(feedback => (
            <tr key={feedback.id}>
              <td>{feedback.name}</td>
              <td>{feedback.email}</td>
              <td>{feedback.feedback}</td>
            </tr>
          ))}
        </tbody>
      </table>
    </div>
    </div>
  );
};

export default FeedbackView;
