import { useState } from 'react';
import '../../assets/css/eventdeatil.css';
import AdminNav from './AdminNav';
import img1 from '../../assets/img/wed.jpg'
import img2 from '../../assets/img/HBD.jpg'
import img3 from '../../assets/img/anni.jpg'

const EventDetails = () => {
  const [events, setEvents] = useState([
    { id: 1, image: img1, name: 'Wedding', description: 'A formal and elegant gown that the bride wears during the ceremony. The dress is often chosen to match the wedding theme and colors.' },
    { id: 2, image: img2, name: 'Birthday Party', description: 'A day filled with fun, laughter, and cake, surrounded by loved ones.A time to celebrate the special person in our lives, with all the things they love' },
    { id: 3, image: img3, name: 'Anniversary', description: 'Celebrating [number] years of love and laughter.Join us for a night of fun and memories as we celebrate our anniversary.' },
  ]);

  const [showModal, setShowModal] = useState(false);
  const [newEventFields, setNewEventFields] = useState({
    image: '',
    name: '',
    description: ''
  });

  const handleInputChange = (e) => {
    const { name, value } = e.target;
    setNewEventFields(prevState => ({
      ...prevState,
      [name]: value
    }));
  };

  const handleNewEvent = () => {
    const newEvent = {
      id: events.length + 1,
      image: newEventFields.image,
      name: newEventFields.name,
      description: newEventFields.description
    };
    setEvents([...events, newEvent]);
    // Reset newEventFields after adding the new event
    setNewEventFields({
      image: '',
      name: '',
      description: ''
    });
    // Close the modal
    setShowModal(false);
  };

  return (
    <div>
      <AdminNav />
      <div className="event-details">
        <button className="new-event-button" onClick={() => setShowModal(true)}>New</button>
        <div className={`modal ${showModal ? 'show' : ''}`}>
          <div className="modal-content">
            <span className="close" onClick={() => setShowModal(false)}>&times;</span>
            <input type="file" name="image" onChange={handleInputChange} value={newEventFields.image} className="event-input" />
            <input type="text" name="name" placeholder="Event Name" onChange={handleInputChange} value={newEventFields.name} className="event-input" />
            <input type="text" name="description" placeholder="Event Description" onChange={handleInputChange} value={newEventFields.description} className="event-input" />
            <button className="new-event-button" onClick={handleNewEvent}>Add New Event</button>
          </div>
        </div>
        <div className="event-cards-container">
          {events.map(event => (
            <div className="event-card" key={event.id}>
              <img src={event.image} alt={event.name} className="event-image" />
              <div className="event-info">
                <h3>{event.name}</h3>
                <p>{event.description}</p>
              </div>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
};

export default EventDetails;
