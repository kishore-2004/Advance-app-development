import  { useState } from 'react';
import '../../assets/css/register.css';

const AdminRegister = () => {
    const [username, setUsername] = useState('');
    const [email, setEmail] = useState('');
    const [password, setPassword] = useState('');

    const handleRegister = () => {
        // Replace this with your actual registration logic
        console.log(`Registering with username: ${username}, email: ${email}, and password: ${password}`);
    };

    return (
        <div id='bgimg'>
        <div className="register-container">
            <h2 id='rh'>Admin</h2>
            <br/>
            <div className="rinput-group">
                <label>Username:</label>
                <input type="text" value={username} onChange={(e) => setUsername(e.target.value)} />
            </div>
            <div className="rinput-group">
                <label>Email:</label>
                <input type="email" value={email} onChange={(e) => setEmail(e.target.value)} />
            </div>
            <div className="rinput-group">
                <label>Password:</label>
                <input type="password" value={password} onChange={(e) => setPassword(e.target.value)} />
            </div>
            <br/>

            <div className='rbutton'>
            <button onClick={handleRegister} id='rb'>Register</button>
            {/* <button onClick={handleRegister}>Register</button> */}

        </div>
        </div>
        </div>
    );
};

export default AdminRegister;
