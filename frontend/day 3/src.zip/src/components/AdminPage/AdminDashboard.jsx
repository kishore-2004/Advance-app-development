
// import React from 'react'
import '../../assets/css/admindashboard.css'
// import AdminNav from './AdminNav'

export default function AdminDashboard() {
  return (
    <div>
      {/* <AdminNav/>0 */}
      <h1>welcome to Admin Dashboard</h1>
    </div>
  )
}
