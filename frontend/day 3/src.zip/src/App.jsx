
import './App.css'
import Login from './components/CustomerPage/userLogin'
import Register from './components/CustomerPage/register'
import Home from './components/CustomerPage/home'
import { BrowserRouter,Routes,Route } from 'react-router-dom'
// import FeedbackForm from './components/CustomerPage/FeedbackForm'
import AllEvents from './components/CustomerPage/AllEvents'
import AllBookings from './components/CustomerPage/AllBookings'
import AddEvent from './components/CustomerPage/AddEvents'
// import BookingForm from './components/CustomerPage/Bookingpage'
import PaymentHistory from './components/CustomerPage/PaymentHistory'
// import ParentComponent from './components/ParentComponent'
import BookingForm from './components/CustomerPage/Bookingpage'
import Profile from './components/CustomerPage/ProfileUser'
import FeedbackForm from './components/CustomerPage/FeedbackForm'

import AdminLogin from './components/AdminPage/Adminlogin'
import AdminRegister from './components/AdminPage/AdminRegister'
import AdminHome from './components/AdminPage/AdminHome'
import AdminDashboard from './components/AdminPage/AdminDashboard'
import ViewBooking from './components/AdminPage/ViewBooking'
import EventDetails from './components/AdminPage/EventsDetail'
import AdminProfile from './components/AdminPage/AdminProfile'
import ViewEvent from './components/CustomerPage/ViewEvents'
import FeedbackView from './components/AdminPage/ViewFeedback'
// import Course from './components/AdminPage/ViewBooking'


function App() {


  return (
    <BrowserRouter>
    <Routes>
      <Route path='/' element = {<Login />} />
      <Route path='/register' element = {<Register />} />
      <Route path='/home' element = {<Home />} />
      <Route path='/logout' element = {<Login />} />
      <Route path="/feedback" element={<FeedbackForm/>} />
      <Route path="/allevents" element={<AllEvents/>} />
      <Route path="/addevents" element={<AddEvent/>} />
      <Route path="/allbookings" element={<AllBookings/>} />
      <Route path="/bookingform" element={<BookingForm/>} />
      <Route path="/paymentHistory" element={<PaymentHistory/>} />
      <Route path="/pofilepage" element={<Profile/>} />
      <Route path="/viewevents" element={<ViewEvent/>} />

      {/* Admin */}
      <Route path="/adminlogin" element={<AdminLogin/>} />
      <Route path="/adminregister" element={<AdminRegister/>} />
      <Route path="/adminhome" element={<AdminHome/>} />
      <Route path="/admindashboard" element={<AdminDashboard/>} />
      <Route path="/viewbooking" element={<ViewBooking/>} />
      <Route path="/eventdetail" element={<EventDetails/>} />
      <Route path="/adminpofile" element={<AdminProfile/>} />
      <Route path="/viewfeedback" element={<FeedbackView/>} />

    </Routes>
    </BrowserRouter>
    
  )
}

export default App
