import { useState } from 'react';
import '../../assets/css/login.css';

const AdminLogin = () => {
    const [Ausername, setUsername] = useState('');
    const [Apassword, setPassword] = useState('');

    const handleLogin = () => {

        console.log(`Logging in as $ with username: ${Ausername} and password: ${Apassword}`);
    };

    return (
        <div>
        <div className="login-container">
            <h2>Admin Login</h2>
            <div className="input-group">
                <label>Username</label>
                <input type="text" value={Ausername} onChange={(e) => setUsername(e.target.value)} />
            </div>
            <div className="input-group">
                {/* <label>Password</label> */}
                <input type="password" value={Apassword} onChange={(e) => setPassword(e.target.value)} />
            </div>
            <button onClick={handleLogin}>Login</button>
        </div>
        </div>
    );
};

export default AdminLogin;
