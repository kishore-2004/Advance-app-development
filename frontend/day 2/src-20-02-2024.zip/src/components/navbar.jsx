import { Link } from "react-router-dom";
import "../assets/css/nav.css";

export const Navbar = () => {
  return (
    <div className="navbar">
    <div className="link">
    <Link to="/home"> Home </Link>
    <Link to="/about"> About us </Link>

    <Link to="/feedback"> feedback </Link>
    </div>
      <div className="links"> 
        </div>
        <div>
      
       </div>
      </div>
  );
};