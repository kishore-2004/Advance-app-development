// import React from "react";
import "../assets/css/home.css";

import { Navbar } from "./navbar";

// import { Link } from "react-router-dom";


 const Home = () => {
  return (
   
    <div className="home">
      <Navbar/>  
      </div>
  );
};
export default Home;