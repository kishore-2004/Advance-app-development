import  { useState } from 'react';
import '../../assets/css/register.css';

const Register = () => {
    const [username, setUsername] = useState('');
    const [email, setEmail] = useState('');
    const [password, setPassword] = useState('');

    const handleRegister = () => {
        // Replace this with your actual registration logic
        console.log(`Registering with username: ${username}, email: ${email}, and password: ${password}`);
    };

    return (
        <div className="register-container">
            <h2>Register</h2>
            <div className="input-group">
                <label>Username:</label>
                <input type="text" value={username} onChange={(e) => setUsername(e.target.value)} />
            </div>
            <div className="input-group">
                <label>Email:</label>
                <input type="email" value={email} onChange={(e) => setEmail(e.target.value)} />
            </div>
            <div className="input-group">
                <label>Password:</label>
                <input type="password" value={password} onChange={(e) => setPassword(e.target.value)} />
            </div>
            <button onClick={handleRegister}>Register</button>
        </div>
    );
};

export default Register;
