package com.partyplanner.partyplanner;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class PartyplannerApplicationTests {

	@Test
	void contextLoads() {
	}

}
