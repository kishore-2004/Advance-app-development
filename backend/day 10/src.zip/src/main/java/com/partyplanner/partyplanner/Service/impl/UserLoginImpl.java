// package com.partyplanner.partyplanner.Service.impl;

// import java.util.List;
// import java.util.stream.Collectors;
// import org.springframework.stereotype.Service;
// import com.partyplanner.partyplanner.Dto.UserLoginDto;
// import com.partyplanner.partyplanner.Entity.UserLogin;
// import com.partyplanner.partyplanner.Repository.UserLoginRepo;
// import com.partyplanner.partyplanner.mapper.UserLoginMapper;
// import com.partyplanner.partyplanner.Service.UserLoginService;
// import com.partyplanner.partyplanner.exception.ResourceNotFoundException;

// import lombok.AllArgsConstructor;

// @Service
// @AllArgsConstructor
// public class UserLoginImpl implements UserLoginService {

//     private UserLoginRepo userLoginRepository;

//     @Override
//     public UserLoginDto createUser(UserLoginDto userLoginDto) {
//         UserLogin userLogin = UserLoginMapper.mapToUserLogin(userLoginDto);
//         UserLogin savedUserLogin = userLoginRepository.save(userLogin);
//         return UserLoginMapper.mapToUserLoginDto(savedUserLogin);
//     }

//     @Override
//     public UserLoginDto getUserByEmail(String email) {
//         UserLogin userLogin = userLoginRepository.findByEmail(email)
//                 .orElseThrow(() -> new ResourceNotFoundException("User with email " + email + " not found"));

//         return UserLoginMapper.mapToUserLoginDto(userLogin);
//     }

//     @Override
//     public List<UserLoginDto> getAllUsers() {
//         List<UserLogin> users = userLoginRepository.findAll();
//         return users.stream()
//                 .map(UserLoginMapper::mapToUserLoginDto)
//                 .collect(Collectors.toList());
//     }
// }
