package com.partyplanner.partyplanner.Service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;

import com.partyplanner.partyplanner.Dto.UserLoginDto;
import com.partyplanner.partyplanner.Repository.UserLoginRepo;

public interface UserLoginService {
    @Autowired
    private UserLoginRepo userrepo;

    UserLoginDto createUser(UserLoginDto UserLoginDto);

    UserLoginDto getUserByEmail(String email);

    List<UserLoginDto> getAllUsers() {
        return userrepo.findAll();
    }
}
