package com.partyplanner.partyplanner;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class PartyplannerApplication {

	public static void main(String[] args) {
		SpringApplication.run(PartyplannerApplication.class, args);
	}
}
