// package com.partyplanner.partyplanner.Repository;

// import org.springframework.data.jpa.repository.JpaRepository;
// import com.partyplanner.partyplanner.Entity.PaymentHistory;

// public interface PaymentHistoryRepo extends JpaRepository <PaymentHistory,Integer> {
    
// }
