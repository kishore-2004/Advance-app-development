package com.example.event.Entity;

public enum Role {
    USER,
    ADMIN
}
